This directory contains any libraries that should be
linked to your project when it is built.
The most common library we will link to is the
Stanford C++ library (cpplib).
