/*************************************************************
 * File: ExtraPQueue.cpp
 *
 * Implementation file for the ExtraPriorityQueue class.  You
 * do not need to implement this class, but we're happy to
 * give you extra credit if you do!
 */
 
#include "ExtraPQueue.h"
#include "error.h"
using namespace std;

ExtraPriorityQueue::ExtraPriorityQueue() {
	// TODO: Fill this in!
}

ExtraPriorityQueue::~ExtraPriorityQueue() {
	// TODO: Fill this in!
}

int ExtraPriorityQueue::size() const {
    // TODO: Fill this in!

    return 0;
}

bool ExtraPriorityQueue::isEmpty() const {
    // TODO: Fill this in!

    return true;
}

void ExtraPriorityQueue::enqueue(const string& value) {
    // TODO: Fill this in!
    (void) value;
}

string ExtraPriorityQueue::peek() const {
    // TODO: Fill this in!

    return "";
}

string ExtraPriorityQueue::dequeueMin() {
    // TODO: Fill this in!

    return "";
}

