/*************************************************************
 * File: SinglyLinkedListPQueue.cpp
 *
 * Implementation file for the SinglyLinkedListPriorityQueue
 * class.
 */
 
#include "SinglyLinkedListPQueue.h"
#include "error.h"
using namespace std;

SinglyLinkedListPriorityQueue::SinglyLinkedListPriorityQueue() {
	// TODO: Fill this in!
}

SinglyLinkedListPriorityQueue::~SinglyLinkedListPriorityQueue() {
	// TODO: Fill this in!
}

int SinglyLinkedListPriorityQueue::size() const {
	// TODO: Fill this in!
	
	return 0;
}

bool SinglyLinkedListPriorityQueue::isEmpty() const {
	// TODO: Fill this in!
	
	return true;
}

void SinglyLinkedListPriorityQueue::enqueue(const string& value) {
	// TODO: Fill this in!
    (void) value;
}

string SinglyLinkedListPriorityQueue::peek() const {
	// TODO: Fill this in!
	
	return "";
}

string SinglyLinkedListPriorityQueue::dequeueMin() {
	// TODO: Fill this in!
	
	return "";
}

