/*************************************************************
 * File: DoublyLinkedListPQueue.cpp
 *
 * Implementation file for the DoublyLinkedListPriorityQueue
 * class.
 */
 
#include "DoublyLinkedListPQueue.h"
#include "error.h"
using namespace std;

DoublyLinkedListPriorityQueue::DoublyLinkedListPriorityQueue() {
	// TODO: Fill this in!
}

DoublyLinkedListPriorityQueue::~DoublyLinkedListPriorityQueue() {
	// TODO: Fill this in!
}

int DoublyLinkedListPriorityQueue::size() const {
	// TODO: Fill this in!
	
	return 0;
}

bool DoublyLinkedListPriorityQueue::isEmpty() const {
	// TODO: Fill this in!
	
	return true;
}

void DoublyLinkedListPriorityQueue::enqueue(const string& value) {
	// TODO: Fill this in!
    (void) value;
}

string DoublyLinkedListPriorityQueue::peek() const {
	// TODO: Fill this in!
	
	return "";
}

string DoublyLinkedListPriorityQueue::dequeueMin() {
	// TODO: Fill this in!
	
	return "";
}

