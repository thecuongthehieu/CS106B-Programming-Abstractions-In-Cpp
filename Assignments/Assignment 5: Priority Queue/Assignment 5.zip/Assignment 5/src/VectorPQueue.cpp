/*************************************************************
 * File: VectorPQueue.cpp
 *
 * Implementation file for the VectorPriorityQueue
 * class.
 */
 
#include "VectorPQueue.h"
#include "error.h"
using namespace std;

VectorPriorityQueue::VectorPriorityQueue() {
	// TODO: Fill this in!
}

VectorPriorityQueue::~VectorPriorityQueue() {
	// TODO: Fill this in!
}

int VectorPriorityQueue::size() const {
	// TODO: Fill this in!
	
	return 0;
}

bool VectorPriorityQueue::isEmpty() const {
	// TODO: Fill this in!
	
	return true;
}

void VectorPriorityQueue::enqueue(const string& value) {
	// TODO: Fill this in!
    (void) value;
}

string VectorPriorityQueue::peek() const {
	// TODO: Fill this in!
	
	return "";
}

string VectorPriorityQueue::dequeueMin() {
	// TODO: Fill this in!
	
	return "";
}

