/*************************************************************
 * File: HeapPQueue.cpp
 *
 * Implementation file for the HeapPriorityQueue
 * class.
 */
 
#include "HeapPQueue.h"
#include "error.h"
using namespace std;

HeapPriorityQueue::HeapPriorityQueue() {
	// TODO: Fill this in!
}

HeapPriorityQueue::~HeapPriorityQueue() {
	// TODO: Fill this in!
}

int HeapPriorityQueue::size() const {
	// TODO: Fill this in!
	
	return 0;
}

bool HeapPriorityQueue::isEmpty() const {
	// TODO: Fill this in!
	
	return true;
}

void HeapPriorityQueue::enqueue(const string& value) {
	// TODO: Fill this in!
    (void) value;
}

string HeapPriorityQueue::peek() const {
	// TODO: Fill this in!
	
	return "";
}

string HeapPriorityQueue::dequeueMin() {
	// TODO: Fill this in!
	
	return "";
}

